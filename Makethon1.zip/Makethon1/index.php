<?php
$insert = false;
if(isset($_POST['name'])){
$server = "localhost";
$username = "root";
$password = "";

$con = mysqli_connect($server, $username, $password);

if(!$con){
    die("Connection to this database failed due to " . mysqli_connect_server());
}
//echo "Successfully connected to the database";

$name = $_POST['name'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$text = $_POST['text'];

$sql = "INSERT INTO `online`.`online` (`Name`, `Contact No.`, `Email`) VALUES ('$name', '$phone', '$email', '$text', current_timestamp());";
//echo $sql;

if($con->query($sql) == true){
    //echo "Successfully inserted.";
    $insert = true;
}
else{
    echo "ERROR: $sql <br> $con->error";
}

$con->close();
}
?>  

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <title>website</title>
</head>
<body>
<?php
        if($insert == true){
        echo "<marquee class='marq'>Thanks</marquee>";
        }
        ?>
    <nav class="navbar background h-nav-resp">
        <ul class="nav-list v-class-resp" style="width: 50%;">
            <div class="logo"><img src="img/book.jpg" alt="logo"></div>
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="popup.html">Contact Us</a></li>
        </ul>
        <div class="rightnav v-class-resp">
            <input type="text" name="search" id="search">
            <button class="btn btn-sm">Search</button>
        </div>
        <div class="burger">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
        </div>
    </nav>
    <section class="background firstSection">
      <div class="box-main">
          <div class="firsthalf">
              <p class="text-big" id="home">GIVE YOUR OLD CLOTHES A SECOND LIFE</p>
              <p class="text-small">MAY THE NEEDY ONE HAVE THEM
                BY GIVING YOUR FEW MINUTES TO ENROLL</p>
              
              
                   <div class="button">
                       <a href="C:\Users\sidpr\.vscode\Makethon1\donate.html" class="btn">Donate</a>
                      
                   </div>
          </div>

         
      </div>
    </section>
<hr>
    <section class="section">
        <div class="paras">
        <p class="sectionTag text-big">Your search for a perfect platform to donate your cloth ends here!</p>
        <p class="sectionSubTag text-small">Are you a guy with cloths of no use.We will be happy to collect those cloths for people who do not have capacity to buy new.</p>
        </div>
            <div class="thumbnail">
                <img src="img/wastecloth.jpg" alt="" class="imgFluid">
            </div>
    </section>
<hr>
    <section class="section section-left" id="services">
        <div class="paras">
        <p class="sectionTag text-big">Our working technique</p>
        <p class="sectionSubTag text-small">We allow you to contact those who need your used cloths.This will be two way interaction between you and poor people </p>
        <a href="details.html" class="learn btn">Learn More about>></a>
        </div>
            <div class="thumbnail">
                <img src="C:\Users\sidpr\.vscode\Makethon1\img\wastecloth.jpeg" alt="cloths pic" class="imgFluid">
            </div>
    </section>
<hr>
    <section class="section" id="about">
        <div class="paras">
        <p class="sectionTag text-big">Our Facilities</p>
        <p class="sectionSubTag text-small">We are doing our best to provide you the best facilities available for the interaction and your personal satisfaction that your cloths are given to the needy people.You can donate cloths of any age which may either be yours or of your family members.</p>
        </div>
            <div class="thumbnail">
                <img src="C:\Users\sidpr\.vscode\Makethon1\img\img.jpeg" alt="cloth pics" class="imgFluid">
            </div>
            <br>
    </section>
<hr>
    <section class="contact" id="contactUs">
        <h2 class="text-center">Create Your Profile Now</h2>
        <form name="myForm" action="index.php" method="post" class="form" onsubmit="return validateForm()">
            <input class="form-input" type="text" name="name" id="name" placeholder="Enter Your Name">
            <br>
      <span id="usererror" class="error"></span>
      <br>
            <input class="form-input" type="text" name="phone" id="phone" placeholder="Enter Your Contact Number">
            <br>
            <span id="gradeerror" class="error"></span>
            <input class="form-input" type="email" name="email" id="email" placeholder="Enter Your e-Mail">
            <input class="form-input" type="text" name="ver" id="ver" placeholder="Set Password">
            
            <button class="btn btn-sm btn-dark ">Submit</button>
            
        </form>
    </section>
    <br>
    <hr>
    <script src="js/resp.js" type="text/javascript"></script>






</body>
</html>